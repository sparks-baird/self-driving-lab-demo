"""Dictionary containing WiFi SSID and password."""
secrets = {"ssid": "Bairds_5G", "password": "Borzoi!s"}
